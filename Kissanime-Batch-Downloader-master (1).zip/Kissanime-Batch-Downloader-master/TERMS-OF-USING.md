### Terms of using this project

By using this project, you agree to the following terms.

* I will use this script for my personal use only.
* I will not commercialize this script and its service.
* I respect KissAnime's Terms and Conditions.
* If found guilty, my offence will be punishable by law.
